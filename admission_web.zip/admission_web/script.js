// Form data storage
let formData = JSON.parse(localStorage.getItem('admissionFormData')) || {};

// Supabase configuration (for demonstration - not recommended for sensitive keys in production)
const SUPABASE_URL = window.SUPABASE_URL;
const SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY;

// Form pages configuration
const formPages = [
    { id: 'personalDetailsForm', title: 'Personal Details' },
    { id: 'coursePreferencesForm', title: 'Course Preferences' },
    { id: 'addressDetailsForm', title: 'Address Details' },
    { id: 'parentDetailsForm', title: 'Parent Details' },
    { id: 'educationalDetailsForm', title: 'Educational Details' },
    { id: 'declarationForm', title: 'Declaration' }
];

let currentPage = 0;

// Course options for UG and PG programs
const courseOptions = {
    ug: [
        { value: "cse", label: "Computer Science and Engineering" },
        { value: "cse-ds", label: "Computer Science and Engineering - Data Science" },
        { value: "cse-ai", label: "Computer Science and Engineering - AI" },
        { value: "cse-cyber", label: "Computer Science and Engineering - Cyber Security" },
        { value: "ise", label: "Information Science and Engineering" },
        { value: "ece", label: "Electronics and Communication Engineering" },
        { value: "mech", label: "Mechanical Engineering" },
        { value: "civil", label: "Civil Engineering" }
    ],
    pg: [
        { value: "mtech", label: "M.Tech" },
        { value: "mba", label: "MBA" },
        { value: "mca", label: "MCA" }
    ]
};

// Initialize Supabase client
let supabaseClient;
window.addEventListener('DOMContentLoaded', function() {
    if (typeof supabase !== 'undefined') {
        supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
});

function updateCourseOptions() {
    const programSelect = document.getElementById('programPreference');
    const courseSelect = document.getElementById('coursePreference');
    
    // Clear existing options
    courseSelect.innerHTML = '<option value="">Select Course</option>';
    
    if (!programSelect.value) return;
    
    // Add new options based on program selection
    const options = courseOptions[programSelect.value] || [];
    options.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option.value;
        optionElement.textContent = option.label;
        courseSelect.appendChild(optionElement);
    });
}

// Helper to prefill declaration fields
function prefillDeclarationFields() {
    const studentNameInput = document.getElementById('studentName');
    const dateInput = document.getElementById('date');
    const lastId = localStorage.getItem('lastPersonalDetailsId');
    if (studentNameInput && lastId && supabaseClient) {
        supabaseClient
            .from('personal_details')
            .select('full_name')
            .eq('id', lastId)
            .single()
            .then(({ data, error }) => {
                if (!error && data && data.full_name) {
                    studentNameInput.value = data.full_name;
                }
            });
        studentNameInput.readOnly = true;
    }
    if (dateInput) {
        // Get current date in IST (Indian Standard Time)
        const now = new Date();
        const istOffset = 5.5 * 60; // IST is UTC+5:30 in minutes
        const localOffset = now.getTimezoneOffset();
        const istTime = new Date(now.getTime() + (istOffset + localOffset) * 60000);
        const istDateString = istTime.toISOString().split('T')[0];
        dateInput.value = istDateString;
        dateInput.readOnly = true;
    }
}

// Initialize form
window.onload = function() {
    // Clear any existing form data
    localStorage.removeItem('admissionFormData');
    formData = {};
    
    // Reset all forms
    const allForms = document.querySelectorAll('form');
    allForms.forEach(form => {
        form.reset();
    });
    
    updateProgressBar();
    
    // Set current date in the declaration form
    const dateInput = document.getElementById('date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
    }

    // Add validation for mobile number
    const mobileInput = document.getElementById('mobile');
    const mobileError = document.getElementById('mobileError');
    if (mobileInput && mobileError) {
        mobileInput.addEventListener('input', function() {
            // Remove any non-digit characters
            this.value = this.value.replace(/[^0-9]/g, '');
            
            // Limit to 10 digits
            if (this.value.length > 10) {
                this.value = this.value.slice(0, 10);
            }
            
            // Validate length
            if (this.value.length !== 10) {
                mobileError.textContent = 'Please enter 10 digits valid mobile number';
                this.classList.add('error');
            } else {
                mobileError.textContent = '';
                this.classList.remove('error');
            }
        });

        // Validate on blur as well
        mobileInput.addEventListener('blur', function() {
            if (this.value.length !== 10) {
                mobileError.textContent = 'Please enter 10 digits valid mobile number';
                this.classList.add('error');
            }
        });
    }

    // Add validation for email
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    if (emailInput && emailError) {
        emailInput.addEventListener('input', function() {
            const email = this.value.trim();
            const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
            
            if (!email) {
                emailError.textContent = 'Please enter valid Email address';
                this.classList.add('error');
            } else if (!gmailRegex.test(email)) {
                emailError.textContent = 'Please enter valid Email address';
                this.classList.add('error');
            } else {
                emailError.textContent = '';
                this.classList.remove('error');
            }
        });

        // Validate on blur as well
        emailInput.addEventListener('blur', function() {
            const email = this.value.trim();
            const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
            
            if (!email) {
                emailError.textContent = 'Email is required';
                this.classList.add('error');
            } else if (!gmailRegex.test(email)) {
                emailError.textContent = 'Please enter a valid Gmail address';
                this.classList.add('error');
            }
        });
    }

    // Add real-time validation for Aadhaar numbers
    const aadhaarInputs = [
        { input: document.getElementById('aadharNo'), error: document.getElementById('aadharError') },
        { input: document.getElementById('fatherAadhaar'), error: document.getElementById('fatherAadhaarError') },
        { input: document.getElementById('motherAadhaar'), error: document.getElementById('motherAadhaarError') }
    ];
    
    aadhaarInputs.forEach(({input, error}) => {
        if (input && error) {
            input.addEventListener('input', function() {
                if (this.value.length > 0 && (this.value.length !== 12 || !/^\d{12}$/.test(this.value))) {
                    error.textContent = 'Please enter a valid 12-digit Aadhaar number';
                    this.classList.add('error');
                } else {
                    error.textContent = '';
                    this.classList.remove('error');
                }
            });
        }
    });

    // Initialize course options if program is already selected
    const programSelect = document.getElementById('programPreference');
    if (programSelect && programSelect.value) {
        updateCourseOptions();
    }

    // Prefill declaration fields if on declaration page
    if (document.getElementById('declarationForm') && document.getElementById('declarationForm').classList.contains('active')) {
        prefillDeclarationFields();
    }

    setupParentMobileValidation();
    setupParentAadhaarValidation();

    // Add event listener for qualification type select
    const qualificationTypeSelect = document.getElementById('qualificationTypeSelect');
    const dynamicQualificationHeading = document.getElementById('dynamicQualificationHeading');
    const twelfthSchoolLabel = document.querySelector('label[for="twelfthSchool"]');
    const twelfthBoardLabel = document.querySelector('label[for="twelfthBoard"]');
    const twelfthYearLabel = document.querySelector('label[for="twelfthYear"]');
    const twelfthPercentageLabel = document.querySelector('label[for="twelfthPercentage"]');

    if (qualificationTypeSelect) {
        qualificationTypeSelect.addEventListener('change', function() {
            const selectedValue = this.value;
            if (selectedValue === 'twelfth') {
                dynamicQualificationHeading.textContent = '12th Details';
                twelfthSchoolLabel.textContent = 'School/College Name';
                twelfthBoardLabel.textContent = 'Board';
                twelfthYearLabel.textContent = 'Year of Passing';
                twelfthPercentageLabel.textContent = 'Percentage';
            } else if (selectedValue === 'diploma') {
                dynamicQualificationHeading.textContent = 'Diploma Details';
                twelfthSchoolLabel.textContent = 'College Name';
                twelfthBoardLabel.textContent = 'Board';
                twelfthYearLabel.textContent = 'Year of Passing';
                twelfthPercentageLabel.textContent = 'Percentage';
            } else {
                dynamicQualificationHeading.textContent = '12th Details'; // Default
                twelfthSchoolLabel.textContent = 'School/College Name';
                twelfthBoardLabel.textContent = 'Board';
                twelfthYearLabel.textContent = 'Year of Passing';
                twelfthPercentageLabel.textContent = 'Percentage';
            }
        });

        // Trigger change on load if a value is already selected (e.g., from saved data)
        if (qualificationTypeSelect.value) {
            qualificationTypeSelect.dispatchEvent(new Event('change'));
        }
    }

    // Capitalize all text input fields
    document.querySelectorAll('input[type="text"]').forEach(input => {
        input.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    });
};

function loadSavedData() {
    const form = document.getElementById(formPages[currentPage].id);
    if (!form) return;

    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        if (formData[input.name]) {
            if (input.type === 'checkbox') {
                input.checked = formData[input.name];
                if (input.id === 'sameAddress') {
                    togglePermanentAddress();
                }
            } else {
                input.value = formData[input.name];
            }
        }
    });
}

function saveCurrentPageData() {
    const form = document.getElementById(formPages[currentPage].id);
    if (!form) return;

    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        if (input.type === 'checkbox') {
            formData[input.name] = input.checked;
        } else if (input.type === 'number') {
            const numValue = input.value.trim();
            formData[input.name] = numValue === '' ? null : parseFloat(numValue);
        } else {
            formData[input.name] = input.value;
        }
    });

    localStorage.setItem('admissionFormData', JSON.stringify(formData));
}

function updateProgressBar() {
    const steps = document.querySelectorAll('.step');
    steps.forEach((step, index) => {
        if (index <= currentPage) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });
}

function validateCurrentPage() {
    const form = document.getElementById(formPages[currentPage].id);
    if (!form) return true;

    const inputs = form.querySelectorAll('input, select');
    let isValid = true;

    inputs.forEach(input => {
        if (input.hasAttribute('required') && !input.value) {
            input.classList.add('error');
            isValid = false;
        } else {
            input.classList.remove('error');
        }
    });

    return isValid;
}

function validateParentDetails() {
    const fatherName = document.getElementById('fatherName').value.trim();
    const fatherMobile = document.getElementById('fatherMobile').value.trim();
    const fatherOccupation = document.getElementById('fatherOccupation').value.trim();
    const fatherAadhaar = document.getElementById('fatherAadhaar').value.trim();
    const fatherIncome = document.getElementById('fatherIncome').value.trim();

    const motherName = document.getElementById('motherName').value.trim();
    const motherMobile = document.getElementById('motherMobile').value.trim();
    const motherOccupation = document.getElementById('motherOccupation').value.trim();
    const motherAadhaar = document.getElementById('motherAadhaar').value.trim();
    const motherIncome = document.getElementById('motherIncome').value.trim();

    const guardianName = document.getElementById('guardianName').value.trim();
    const guardianMobile = document.getElementById('guardianMobile').value.trim();
    const guardianOccupation = document.getElementById('guardianOccupation').value.trim();
    const guardianAadhaar = document.getElementById('guardianAadhaar').value.trim();
    const guardianIncome = document.getElementById('guardianIncome').value.trim();
    const guardianRelation = document.getElementById('guardianRelation').value;

    const guardianFilled = guardianName || guardianMobile || guardianOccupation || guardianAadhaar || guardianIncome || guardianRelation;

    // Validate mobile numbers if provided
    const mobileRegex = /^[0-9]{10}$/;
    
    if (fatherMobile && !mobileRegex.test(fatherMobile)) {
        document.getElementById('fatherMobileError').textContent = 'Please enter 10 digits valid mobile number';
        document.getElementById('fatherMobile').classList.add('error');
        return false;
    }

    if (motherMobile && !mobileRegex.test(motherMobile)) {
        document.getElementById('motherMobileError').textContent = 'Please enter 10 digits valid mobile number';
        document.getElementById('motherMobile').classList.add('error');
        return false;
    }

    if (guardianMobile && !mobileRegex.test(guardianMobile)) {
        document.getElementById('guardianMobileError').textContent = 'Please enter 10 digits valid mobile number';
        document.getElementById('guardianMobile').classList.add('error');
        return false;
    }

    // Validate Aadhaar numbers if provided
    const aadhaarRegex = /^[0-9]{12}$/;

    if (fatherAadhaar && !aadhaarRegex.test(fatherAadhaar)) {
        document.getElementById('fatherAadhaarError').textContent = 'Please enter valid 12-digit Aadhaar number';
        document.getElementById('fatherAadhaar').classList.add('error');
        return false;
    }

    if (motherAadhaar && !aadhaarRegex.test(motherAadhaar)) {
        document.getElementById('motherAadhaarError').textContent = 'Please enter valid 12-digit Aadhaar number';
        document.getElementById('motherAadhaar').classList.add('error');
        return false;
    }

    if (guardianAadhaar && !aadhaarRegex.test(guardianAadhaar)) {
        document.getElementById('guardianAadhaarError').textContent = 'Please enter valid 12-digit Aadhaar number';
        document.getElementById('guardianAadhaar').classList.add('error');
        return false;
    }

    // If guardian details are filled, relationship is required
    if (guardianFilled && !guardianRelation) {
        alert('Please select relationship with guardian');
        return false;
    }

    return true;
}

function setupParentMobileValidation() {
    const mobileInputs = ['fatherMobile', 'motherMobile', 'guardianMobile'];
    
    mobileInputs.forEach(id => {
        const input = document.getElementById(id);
        const errorSpan = document.getElementById(id + 'Error');

        input.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 10) {
                this.value = this.value.slice(0, 10);
            }
            
            if (this.value.length === 10) {
                errorSpan.textContent = '';
                this.classList.remove('error');
            } else if (this.value.length > 0) {
                errorSpan.textContent = 'Please enter 10 digits valid mobile number';
                this.classList.add('error');
            } else {
                errorSpan.textContent = '';
                this.classList.remove('error');
            }
        });

        input.addEventListener('blur', function() {
            if (this.value.length > 0 && this.value.length !== 10) {
                errorSpan.textContent = 'Please enter 10 digits valid mobile number';
                this.classList.add('error');
            }
        });
    });
}

function setupParentAadhaarValidation() {
    const aadhaarInputs = ['fatherAadhaar', 'motherAadhaar', 'guardianAadhaar'];
    
    aadhaarInputs.forEach(id => {
        const input = document.getElementById(id);
        const errorSpan = document.getElementById(id + 'Error');

        input.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length > 12) {
                this.value = this.value.slice(0, 12);
            }
            
            if (this.value.length === 12) {
                errorSpan.textContent = '';
                this.classList.remove('error');
            } else if (this.value.length > 0) {
                errorSpan.textContent = 'Please enter valid 12-digit Aadhaar number';
                this.classList.add('error');
            } else {
                errorSpan.textContent = '';
                this.classList.remove('error');
            }
        });

        input.addEventListener('blur', function() {
            if (this.value.length > 0 && this.value.length !== 12) {
                errorSpan.textContent = 'Please enter valid 12-digit Aadhaar number';
                this.classList.add('error');
            }
        });
    });
}

function saveAndNext(nextPage) {
    if (currentPage === 4) { // Parent Details page
        if (!validateParentDetails()) {
            return;
        }
    }
    if (typeof supabaseClient === 'undefined' || !supabaseClient) {
        alert('Supabase client not loaded. Please check your internet connection and script includes.');
        return;
    }
    // Get the current form
    const currentForm = document.querySelector('.form-section.active');
    
    // Validate form fields
    if (!validateForm(currentForm)) {
        return;
    }

    // Additional validation for Aadhaar number when on personal details form
    if (currentForm.id === 'personalDetailsForm') {
        const aadharInput = document.getElementById('aadharNo');
        const aadharError = document.getElementById('aadharError');
        
        if (aadharInput.value.length !== 12 || !/^\d{12}$/.test(aadharInput.value)) {
            aadharError.textContent = 'Please enter a valid 12-digit Aadhaar number';
            aadharInput.classList.add('error');
            aadharInput.focus();
            return;
        } else {
            aadharError.textContent = '';
            aadharInput.classList.remove('error');
        }

        // Disable button to prevent multiple submissions
        const nextBtn = currentForm.querySelector('button.btn.btn-primary');
        if (nextBtn) nextBtn.disabled = true;

        // --- Supabase Insert for Personal Details ---
        const name = document.getElementById('name').value;
        const mobile = document.getElementById('mobile').value;
        const email = document.getElementById('email').value;
        const dob = document.getElementById('dob').value;
        const gender = document.getElementById('gender').value;
        const religion = document.getElementById('religion').value;
        const category = document.getElementById('category').value;
        const aadharNo = document.getElementById('aadharNo').value;

        supabaseClient
            .from('personal_details')
            .insert([
                {
                    name,
                    mobile,
                    email,
                    dob,
                    gender,
                    religion,
                    category,
                    aadhar_no: aadharNo
                }
            ])
            .select()
            .then(({ data, error }) => {
                if (nextBtn) nextBtn.disabled = false;
                if (error) {
                    alert('Failed to save personal details: ' + error.message);
                    return;
                } else {
                    // Store the inserted row id in localStorage for later updates
                    if (data && data.length > 0 && data[0].id) {
                        localStorage.setItem('lastPersonalDetailsId', data[0].id);
                    }
                    // Hide current form
                    currentForm.classList.remove('active');
                    // Show next form (Course Preferences)
                    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
                    nextForm.classList.add('active');
                    // Update progress bar
                    updateProgressBar(nextPage);
                }
            });
        return; // Prevent default navigation until insert completes
    }

    // Handle Course Preferences Form
    if (currentForm.id === 'coursePreferencesForm') {
        const programPreference = document.getElementById('programPreference').value;
        const coursePreference = document.getElementById('coursePreference').value;
        const lastId = localStorage.getItem('lastPersonalDetailsId');
        if (!lastId) {
            alert('No personal details record found. Please fill the first page first.');
            return;
        }
        // Disable button to prevent multiple submissions
        const nextBtn = currentForm.querySelector('button.btn.btn-primary');
        if (nextBtn) nextBtn.disabled = true;
        supabaseClient
            .from('personal_details')
            .update({
                program_preference: programPreference,
                course_preference: coursePreference
            })
            .eq('id', lastId)
            .then(({ error }) => {
                if (nextBtn) nextBtn.disabled = false;
                if (error) {
                    alert('Failed to save course preferences: ' + error.message);
                    return;
                } else {
                    // Hide current form
                    currentForm.classList.remove('active');
                    // Show next form (Address Details)
                    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
                    nextForm.classList.add('active');
                    // Update progress bar
                    updateProgressBar(nextPage);
                }
            });
        return;
    }

    // Handle Address Details Form
    if (currentForm.id === 'addressDetailsForm') {
        const commAddressLine1 = document.getElementById('commAddressLine1').value;
        const commAddressLine2 = document.getElementById('commAddressLine2').value;
        const commCity = document.getElementById('commCity').value;
        const commState = document.getElementById('commState').value;
        const commPincode = document.getElementById('commPincode').value;
        const permAddressLine1 = document.getElementById('permAddressLine1').value;
        const permAddressLine2 = document.getElementById('permAddressLine2').value;
        const permCity = document.getElementById('permCity').value;
        const permState = document.getElementById('permState').value;
        const permPincode = document.getElementById('permPincode').value;
        const sameAddress = document.getElementById('sameAddress').checked;
        const lastId = localStorage.getItem('lastPersonalDetailsId');
        if (!lastId) {
            alert('No personal details record found. Please fill the first page first.');
            return;
        }
        // Custom validation: if sameAddress is not checked, permanent address fields are required
        if (!sameAddress) {
            let permValid = true;
            [
                { el: document.getElementById('permAddressLine1'), name: 'Address Line 1' },
                { el: document.getElementById('permCity'), name: 'City' },
                { el: document.getElementById('permState'), name: 'State' },
                { el: document.getElementById('permPincode'), name: 'Pincode' }
            ].forEach(({el, name}) => {
                if (!el.value.trim()) {
                    el.classList.add('error');
                    permValid = false;
                } else {
                    el.classList.remove('error');
                }
            });
            if (!permValid) {
                alert('Please fill in all required Permanent Address fields');
                return;
            }
        }
        const nextBtn = currentForm.querySelector('button.btn.btn-primary');
        if (nextBtn) nextBtn.disabled = true;
        supabaseClient
            .from('personal_details')
            .update({
                comm_address_line1: commAddressLine1,
                comm_address_line2: commAddressLine2,
                comm_city: commCity,
                comm_state: commState,
                comm_pincode: commPincode,
                perm_address_line1: permAddressLine1,
                perm_address_line2: permAddressLine2,
                perm_city: permCity,
                perm_state: permState,
                perm_pincode: permPincode
            })
            .eq('id', lastId)
            .then(({ error }) => {
                if (nextBtn) nextBtn.disabled = false;
                if (error) {
                    alert('Failed to save address details: ' + error.message);
                    return;
                } else {
                    currentForm.classList.remove('active');
                    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
                    nextForm.classList.add('active');
                    updateProgressBar(nextPage);
                }
            });
        return;
    }

    // Handle Parent Details Form
    if (currentForm.id === 'parentDetailsForm') {
        const fatherName = document.getElementById('fatherName').value;
        const fatherMobile = document.getElementById('fatherMobile').value;
        const fatherOccupation = document.getElementById('fatherOccupation').value;
        const fatherAadhaar = document.getElementById('fatherAadhaar').value;
        const fatherIncome = document.getElementById('fatherIncome').value.trim();

        const motherName = document.getElementById('motherName').value;
        const motherMobile = document.getElementById('motherMobile').value;
        const motherOccupation = document.getElementById('motherOccupation').value;
        const motherAadhaar = document.getElementById('motherAadhaar').value;
        const motherIncome = document.getElementById('motherIncome').value.trim();

        const guardianName = document.getElementById('guardianName').value;
        const guardianMobile = document.getElementById('guardianMobile').value;
        const guardianOccupation = document.getElementById('guardianOccupation').value;
        const guardianAadhaar = document.getElementById('guardianAadhaar').value;
        const guardianIncome = document.getElementById('guardianIncome').value.trim();
        const guardianRelation = document.getElementById('guardianRelation').value;

        // Helper to convert empty string to null for numeric fields
        const toNullIfEmpty = (value) => (value === '' ? null : parseFloat(value));

        const lastId = localStorage.getItem('lastPersonalDetailsId');
        if (!lastId) {
            alert('No personal details record found. Please fill the first page first.');
            return;
        }
        const nextBtn = currentForm.querySelector('button.btn.btn-primary');
        if (nextBtn) nextBtn.disabled = true;
        supabaseClient
            .from('personal_details')
            .update({
                father_name: fatherName,
                father_mobile: fatherMobile,
                father_occupation: fatherOccupation,
                father_aadhaar: fatherAadhaar,
                father_income: toNullIfEmpty(fatherIncome),
                mother_name: motherName,
                mother_mobile: motherMobile,
                mother_occupation: motherOccupation,
                mother_aadhaar: motherAadhaar,
                mother_income: toNullIfEmpty(motherIncome),
                guardian_name: guardianName,
                guardian_mobile: guardianMobile,
                guardian_occupation: guardianOccupation,
                guardian_aadhaar: guardianAadhaar,
                guardian_income: toNullIfEmpty(guardianIncome),
                guardian_relation: guardianRelation
            })
            .eq('id', lastId)
            .then(({ error }) => {
                if (nextBtn) nextBtn.disabled = false;
                if (error) {
                    alert('Failed to save parent details: ' + error.message);
                    return;
                } else {
                    currentForm.classList.remove('active');
                    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
                    nextForm.classList.add('active');
                    updateProgressBar(nextPage);
                }
            });
        return;
    }

    // Handle Educational Details Form
    if (currentForm.id === 'educationalDetailsForm') {
        const tenthSchool = document.getElementById('tenthSchool').value;
        const tenthBoard = document.getElementById('tenthBoard').value;
        const tenthYear = document.getElementById('tenthYear').value;
        const tenthPercentage = document.getElementById('tenthPercentage').value;
        const qualificationType = document.getElementById('qualificationTypeSelect').value;
        const twelfthSchool = document.getElementById('twelfthSchool').value;
        const twelfthBoard = document.getElementById('twelfthBoard').value;
        const twelfthYear = document.getElementById('twelfthYear').value;
        const twelfthPercentage = document.getElementById('twelfthPercentage').value;
        const lastId = localStorage.getItem('lastPersonalDetailsId');
        if (!lastId) {
            alert('No personal details record found. Please fill the first page first.');
            return;
        }
        const nextBtn = currentForm.querySelector('button.btn.btn-primary');
        if (nextBtn) nextBtn.disabled = true;
        let updateData = {
            tenth_school: tenthSchool,
            tenth_board: tenthBoard,
            tenth_year: tenthYear,
            tenth_percentage: tenthPercentage,
            qualification_type: qualificationType
        };
        if (qualificationType === 'twelfth') {
            updateData = {
                ...updateData,
                twelfth_school: twelfthSchool,
                twelfth_board: twelfthBoard,
                twelfth_year: twelfthYear,
                twelfth_percentage: twelfthPercentage,
                diploma_school: null,
                diploma_board: null,
                diploma_year: null,
                diploma_percentage: null
            };
        } else if (qualificationType === 'diploma') {
            updateData = {
                ...updateData,
                twelfth_school: null,
                twelfth_board: null,
                twelfth_year: null,
                twelfth_percentage: null,
                diploma_school: twelfthSchool,
                diploma_board: twelfthBoard,
                diploma_year: twelfthYear,
                diploma_percentage: twelfthPercentage
            };
        }
        supabaseClient
            .from('personal_details')
            .update(updateData)
            .eq('id', lastId)
            .then(({ error }) => {
                if (nextBtn) nextBtn.disabled = false;
                if (error) {
                    alert('Failed to save educational details: ' + error.message);
                    return;
                } else {
                    currentForm.classList.remove('active');
                    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
                    nextForm.classList.add('active');
                    updateProgressBar(nextPage);
                }
            });
        return;
    }

    // Hide current form
    currentForm.classList.remove('active');
    
    // Show next form
    const nextForm = document.querySelector(`#${getFormIdByStep(nextPage)}`);
    nextForm.classList.add('active');
    
    // Update progress bar
    updateProgressBar(nextPage);
}

function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.classList.add('error');
        } else {
            // Additional validation for specific fields
            if (input.type === 'tel' && input.value.length !== 10) {
                isValid = false;
                input.classList.add('error');
                const errorElement = document.getElementById(input.id + 'Error');
                if (errorElement) {
                    errorElement.textContent = 'Please enter exactly 10 digits';
                }
            } else if (input.type === 'email') {
                const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
                if (!gmailRegex.test(input.value.trim())) {
                    isValid = false;
                    input.classList.add('error');
                    const errorElement = document.getElementById(input.id + 'Error');
                    if (errorElement) {
                        errorElement.textContent = 'Please enter a valid Gmail address';
                    }
                }
            } else {
                input.classList.remove('error');
            }
        }
    });
    
    if (!isValid) {
        alert('Please fill in all required fields correctly');
    }
    
    return isValid;
}

function getFormIdByStep(step) {
    switch(step) {
        case 1: return 'personalDetailsForm';
        case 2: return 'coursePreferencesForm';
        case 3: return 'addressDetailsForm';
        case 4: return 'parentDetailsForm';
        case 5: return 'educationalDetailsForm';
        case 6: return 'declarationForm';
        default: return 'personalDetailsForm';
    }
}

function updateProgressBar(currentStep) {
    const steps = document.querySelectorAll('.step');
    steps.forEach((step, index) => {
        if (index < currentStep) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });
}

function navigateToPage(step) {
    const currentForm = document.querySelector('.form-section.active');
    currentForm.classList.remove('active');
    
    const targetForm = document.querySelector(`#${getFormIdByStep(step)}`);
    targetForm.classList.add('active');
    
    updateProgressBar(step);
    if (targetForm.id === 'declarationForm') {
        prefillDeclarationFields();
    }
}

function togglePermanentAddress() {
    const sameAddress = document.getElementById('sameAddress');
    const permanentAddressSection = document.getElementById('permanentAddressSection');
    
    if (sameAddress.checked) {
        // Copy communication address to permanent address
        document.getElementById('permAddressLine1').value = document.getElementById('commAddressLine1').value;
        document.getElementById('permAddressLine2').value = document.getElementById('commAddressLine2').value;
        document.getElementById('permCity').value = document.getElementById('commCity').value;
        document.getElementById('permState').value = document.getElementById('commState').value;
        document.getElementById('permPincode').value = document.getElementById('commPincode').value;
        
        permanentAddressSection.style.display = 'none';
    } else {
        permanentAddressSection.style.display = 'block';
    }
}

function submitForm() {
    const declarationForm = document.getElementById('declarationForm');
    if (!validateForm(declarationForm)) {
        return;
    }
    if (!document.getElementById('agreementCheckbox').checked) {
        alert('Please agree to the declaration before submitting');
        return;
    }
    // Get values
    const agreed = document.getElementById('agreementCheckbox').checked;
    const studentName = document.getElementById('studentName').value;
    const date = document.getElementById('date').value;
    const lastId = localStorage.getItem('lastPersonalDetailsId');
    if (!lastId) {
        alert('No personal details record found. Please fill the first page first.');
        return;
    }
    const submitBtn = declarationForm.querySelector('button.btn.btn-primary');
    if (submitBtn) submitBtn.disabled = true;
    supabaseClient
        .from('personal_details')
        .update({
            declaration_agreed: agreed,
            declaration_student_name: studentName,
            declaration_date: date
        })
        .eq('id', lastId)
        .select()
        .then(({ error }) => {
            if (submitBtn) submitBtn.disabled = false;
            if (error) {
                alert('Failed to submit declaration: ' + error.message);
                return;
            } else {
                showSuccessAnimation(); // Call success animation
                setTimeout(() => {
                    // Clear form data after successful submission and animation
                    localStorage.removeItem('admissionFormData');
                    localStorage.removeItem('lastPersonalDetailsId');
                    formData = {};
                    // Reset all forms and navigate back to the first page
                    document.querySelectorAll('form').forEach(form => form.reset());
                    navigateToPage(1);
                    hideSuccessAnimation();
                }, 3000); // Hide after 3 seconds
            }
        });
}

function showSuccessAnimation() {
    const successOverlay = document.getElementById('successOverlay');
    if (successOverlay) {
        successOverlay.style.display = 'flex';
        const sparklesContainer = document.querySelector('.sparkles-container');
        if (sparklesContainer) {
            sparklesContainer.innerHTML = ''; // Clear previous sparkles
            for (let i = 0; i < 30; i++) {
                createSparkle(sparklesContainer);
            }
        }
    }
}

function hideSuccessAnimation() {
    const successOverlay = document.getElementById('successOverlay');
    if (successOverlay) {
        successOverlay.style.display = 'none';
    }
}

function createSparkle(container) {
    const sparkle = document.createElement('div');
    sparkle.classList.add('sparkle');
    sparkle.style.left = `${Math.random() * 100}%`;
    sparkle.style.top = `${Math.random() * 100}%`;
    sparkle.style.animationDuration = `${0.5 + Math.random() * 0.5}s`;
    sparkle.style.animationDelay = `${Math.random() * 1.5}s`;
    container.appendChild(sparkle);

    // Remove sparkle after animation to prevent DOM bloat
    sparkle.addEventListener('animationend', () => {
        sparkle.remove();
    });
}

function generatePrintPreview() {
    saveCurrentPageData(); // Ensure current page data is saved to formData

    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Admission Form Preview</title>');
    printWindow.document.write('<style>');
    printWindow.document.write(`
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
        h1, h2, h3 { color: #2c3e50; border-bottom: 2px solid #e9ecef; padding-bottom: 5px; margin-top: 20px; }
        .section { margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px dashed #ccc; }
        .field { margin-bottom: 8px; }
        .field strong { display: inline-block; width: 180px; }
        .declaration-text ol { padding-left: 20px; }
        .declaration-text li { margin-bottom: 5px; }
        @media print {
            .no-print { display: none; }
        }
    `);
    printWindow.document.write('</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h1>Admission Form Details</h1>');

    // Personal Details
    printWindow.document.write('<h2>Personal Details</h2>');
    printWindow.document.write('<div class="section">');
    printWindow.document.write(`<div class="field"><strong>Full Name:</strong> ${formData.fullName || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Email:</strong> ${formData.email || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Mobile Number:</strong> ${formData.mobile || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Date of Birth:</strong> ${formData.dob || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Gender:</strong> ${formData.gender || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Nationality:</strong> ${formData.nationality || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Religion:</strong> ${formData.religion || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Caste Category:</strong> ${formData.casteCategory || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Aadhaar Number:</strong> ${formData.aadharNo || 'N/A'}</div>`);
    printWindow.document.write('</div>');

    // Course Preferences
    printWindow.document.write('<h2>Course Preferences</h2>');
    printWindow.document.write('<div class="section">');
    printWindow.document.write(`<div class="field"><strong>Program Preference:</strong> ${formData.programPreference || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Course Preference:</strong> ${formData.coursePreference || 'N/A'}</div>`);
    printWindow.document.write('</div>');

    // Address Details
    printWindow.document.write('<h2>Address Details</h2>');
    printWindow.document.write('<div class="section">');
    printWindow.document.write('<h3>Communication Address</h3>');
    printWindow.document.write(`<div class="field"><strong>Address Line 1:</strong> ${formData.commAddressLine1 || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Address Line 2 (District):</strong> ${formData.commAddressLine2 || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>City:</strong> ${formData.commCity || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>State:</strong> ${formData.commState || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Pincode:</strong> ${formData.commPincode || 'N/A'}</div>`);
    
    if (formData.sameAddress !== true) { // Only show permanent address if not same
        printWindow.document.write('<h3>Permanent Address</h3>');
        printWindow.document.write(`<div class="field"><strong>Address Line 1:</strong> ${formData.permAddressLine1 || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Address Line 2 (District):</strong> ${formData.permAddressLine2 || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>City:</strong> ${formData.permCity || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>State:</strong> ${formData.permState || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Pincode:</strong> ${formData.permPincode || 'N/A'}</div>`);
    }
    printWindow.document.write('</div>');

    // Parent/Guardian Details
    printWindow.document.write('<h2>Parent/Guardian Details</h2>');
    printWindow.document.write('<div class="section">');

    if (formData.fatherName || formData.fatherMobile || formData.fatherOccupation || formData.fatherAadhaar || formData.fatherIncome) {
        printWindow.document.write(`<h3>Father's Details</h3>`);
        printWindow.document.write(`<div class="field"><strong>Name:</strong> ${formData.fatherName || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Mobile:</strong> ${formData.fatherMobile || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Occupation:</strong> ${formData.fatherOccupation || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Aadhaar:</strong> ${formData.fatherAadhaar || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Annual Income:</strong> ${formData.fatherIncome !== null ? formData.fatherIncome : 'N/A'}</div>`);
    }

    if (formData.motherName || formData.motherMobile || formData.motherOccupation || formData.motherAadhaar || formData.motherIncome) {
        printWindow.document.write(`<h3>Mother's Details</h3>`);
        printWindow.document.write(`<div class="field"><strong>Name:</strong> ${formData.motherName || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Mobile:</strong> ${formData.motherMobile || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Occupation:</strong> ${formData.motherOccupation || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Aadhaar:</strong> ${formData.motherAadhaar || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Annual Income:</strong> ${formData.motherIncome !== null ? formData.motherIncome : 'N/A'}</div>`);
    }

    if (formData.guardianName || formData.guardianMobile || formData.guardianOccupation || formData.guardianAadhaar || formData.guardianIncome || formData.guardianRelation) {
        printWindow.document.write(`<h3>Guardian's Details</h3>`);
        printWindow.document.write(`<div class="field"><strong>Name:</strong> ${formData.guardianName || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Mobile:</strong> ${formData.guardianMobile || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Occupation:</strong> ${formData.guardianOccupation || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Aadhaar:</strong> ${formData.guardianAadhaar || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Annual Income:</strong> ${formData.guardianIncome !== null ? formData.guardianIncome : 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Relationship:</strong> ${formData.guardianRelation || 'N/A'}</div>`);
    }
    printWindow.document.write('</div>');

    // Educational Details
    printWindow.document.write('<h2>Educational Details</h2>');
    printWindow.document.write('<div class="section">');
    printWindow.document.write('<h3>10th Details</h3>');
    printWindow.document.write(`<div class="field"><strong>School Name:</strong> ${formData.tenthSchool || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Board:</strong> ${formData.tenthBoard || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Year of Passing:</strong> ${formData.tenthYear || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Percentage:</strong> ${formData.tenthPercentage || 'N/A'}</div>`);
    
    if (formData.qualificationType) {
        printWindow.document.write(`<h3>${formData.qualificationType === 'twelfth' ? '12th Details' : 'Diploma Details'}</h3>`);
        printWindow.document.write(`<div class="field"><strong>School/College Name:</strong> ${formData.twelfthSchool || formData.diplomaSchool || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Board:</strong> ${formData.twelfthBoard || formData.diplomaBoard || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Year of Passing:</strong> ${formData.twelfthYear || formData.diplomaYear || 'N/A'}</div>`);
        printWindow.document.write(`<div class="field"><strong>Percentage:</strong> ${formData.twelfthPercentage || formData.diplomaPercentage || 'N/A'}</div>`);
    }
    printWindow.document.write('</div>');

    // Declaration Details
    printWindow.document.write('<h2>Declaration</h2>');
    printWindow.document.write('<div class="section">');
    printWindow.document.write(`<div class="field"><strong>Declaration Agreed:</strong> ${formData.agreementCheckbox ? 'Yes' : 'No'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Student Name:</strong> ${formData.studentName || 'N/A'}</div>`);
    printWindow.document.write(`<div class="field"><strong>Date:</strong> ${formData.date || 'N/A'}</div>`);
    printWindow.document.write('</div>');

    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print(); // Open print dialog
}